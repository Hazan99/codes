require("./database/module")
global.owner = "6282130493798"
global.namabot = "*ZavPiwww*"
global.nomorbot = "6282130493798"
global.namacreator = "*ZavMods* ϟ"
global.linkyt = false
global.autoJoin = false
global.antilink = false
global.versisc = '2.0'
global.codeInvite = ""
global.imageurl = 'https://pomf2.lain.la/f/miuqdl.jpg'
global.isLink = 'https://whatsapp.com/channel/0029VajfpOu2kNFv4ffAT735'
global.packname = "ZavDev"
global.author = "ZavOwn"
global.jumlah = "5"

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})