require("./database/module")

//GLOBAL PAYMENT
global.storename = "𝐓𝐡𝐞𝐆𝐞𝐭𝐬𝐮𝐳𝐨𝐙𝐡𝐢𝐫𝐨🐉"
global.dana = "-"
global.qris = "heylink.me/energybomboy"


// GLOBAL SETTING
global.owner = "2348033848356"
global.namabot = "CRYPTO LORD"
global.nomorbot = "2348033848356"
global.namacreator = "CRYPTO LORD "
global.linkyt = "heylink.me/energybomboy"
global.autoJoin = false
global.antilink = false
global.versisc = '𝟭𝟮.𝟬.𝟬'

// DELAY JPM
global.delayjpm = 5500

// SETTING PANEL
global.apikey = 'PLTC'
global.capikey = 'PLTA'
global.domain = 'https://domain.com'
global.eggsnya = '15'
global.location = '1'



//GLOBAL THUMB

global.codeInvite = ""
global.imageurl = 'https://files.catbox.moe/0r1tfu.jpeg'
global.isLink = 'https://whatsapp.com/channel/0029VajOKquG3R3pOUajb71j'
global.packname = "Crypto Lord "
global.author = "Crypto 𝐈𝐬 𝐇𝐞𝐫𝐞 ϟ"
global.jumlah = "5"


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})